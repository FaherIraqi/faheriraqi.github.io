import { Text, View, ScrollView, SafeAreaView, TouchableOpacity, Alert, Share } from 'react-native';
import { router } from 'expo-router';
import { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import QRCode from 'react-native-qrcode-svg';
import Button from '../components/Button';
import Logo from '../components/Logo';
import { commonStyles, buttonStyles, colors } from '../styles/commonStyles';
import { useLanguage } from '../contexts/LanguageContext';

export default function QRCodeScreen() {
  const { t, isRTL } = useLanguage();
  const [qrValue, setQrValue] = useState('https://tirameatboutique.com');

  const goBack = () => {
    console.log('Going back to main screen');
    router.back();
  };

  const shareQRCode = async () => {
    try {
      await Share.share({
        message: `${t('visitOurStore')}: ${qrValue}`,
        title: t('tiraMeatBoutique'),
      });
    } catch (error) {
      console.error('Error sharing QR code:', error);
      Alert.alert(t('error'), t('shareError'));
    }
  };

  return (
    <SafeAreaView style={commonStyles.wrapper}>
      {/* Header with Back Button */}
      <View style={[commonStyles.header, { direction: isRTL ? 'rtl' : 'ltr' }]}>
        <TouchableOpacity 
          style={[commonStyles.backButton, isRTL && { transform: [{ scaleX: -1 }] }]}
          onPress={goBack}
        >
          <Ionicons name="arrow-back" size={24} color={colors.primary} />
        </TouchableOpacity>
        <Text style={[commonStyles.headerTitle, { textAlign: 'center', flex: 1 }]}>
          {t('qrCodeGenerator')}
        </Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={commonStyles.scrollContent}>
        <View style={[commonStyles.content, { direction: isRTL ? 'rtl' : 'ltr' }]}>
          {/* Logo Section */}
          <View style={[commonStyles.card, { alignItems: 'center', marginBottom: 20 }]}>
            <Logo size="small" showText={true} />
          </View>

          {/* QR Code Display */}
          <View style={[commonStyles.card, { alignItems: 'center' }]}>
            <Text style={[commonStyles.subtitle, { marginBottom: 20, textAlign: 'center' }]}>
              {t('storeQRCode')}
            </Text>
            
            <View style={commonStyles.qrContainer}>
              <QRCode
                value={qrValue}
                size={200}
                color={colors.background}
                backgroundColor={colors.text}
                logoSize={30}
                logoBackgroundColor="transparent"
                logoMargin={4}
                logoBorderRadius={15}
                quietZone={10}
              />
            </View>

            <Text style={[commonStyles.text, { 
              marginTop: 15, 
              textAlign: 'center',
              maxWidth: 280,
              lineHeight: 22
            }]}>
              {t('scanWithCamera')}
            </Text>
            
            <View style={[commonStyles.urlContainer, { marginTop: 10 }]}>
              <Text style={[commonStyles.urlText, { textAlign: 'center' }]}>
                {qrValue}
              </Text>
            </View>
          </View>

          {/* Store Information */}
          <View style={commonStyles.card}>
            <Text style={[commonStyles.subtitle, { marginBottom: 15, textAlign: 'center' }]}>
              {t('qrCodeInfo')}
            </Text>
            <View style={{ gap: 15 }}>
              <View style={[commonStyles.infoRow, { 
                flexDirection: isRTL ? 'row-reverse' : 'row'
              }]}>
                <View style={commonStyles.iconContainer}>
                  <Ionicons name="storefront" size={20} color={colors.primary} />
                </View>
                <Text style={[commonStyles.infoText, { flex: 1, textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('storeLocation')}
                </Text>
              </View>
              
              <View style={[commonStyles.infoRow, { 
                flexDirection: isRTL ? 'row-reverse' : 'row'
              }]}>
                <View style={commonStyles.iconContainer}>
                  <Ionicons name="time" size={20} color={colors.primary} />
                </View>
                <Text style={[commonStyles.infoText, { flex: 1, textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('openingHours')}
                </Text>
              </View>
              
              <View style={[commonStyles.infoRow, { 
                flexDirection: isRTL ? 'row-reverse' : 'row'
              }]}>
                <View style={commonStyles.iconContainer}>
                  <Ionicons name="call" size={20} color={colors.primary} />
                </View>
                <Text style={[commonStyles.infoText, { flex: 1, textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('contactNumber')}
                </Text>
              </View>
              
              <View style={[commonStyles.infoRow, { 
                flexDirection: isRTL ? 'row-reverse' : 'row'
              }]}>
                <View style={commonStyles.iconContainer}>
                  <Ionicons name="star" size={20} color={colors.primary} />
                </View>
                <Text style={[commonStyles.infoText, { flex: 1, textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('premiumQuality')}
                </Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={commonStyles.buttonContainer}>
            <Button
              text={t('shareQRCode')}
              onPress={shareQRCode}
              style={[buttonStyles.primary, { marginBottom: 15 }]}
            />
            <Button
              text={t('backToMain')}
              onPress={goBack}
              style={buttonStyles.secondary}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}