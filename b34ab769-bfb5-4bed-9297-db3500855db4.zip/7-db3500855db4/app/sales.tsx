import { Text, View, ScrollView, SafeAreaView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { useState, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import Button from '../components/Button';
import Logo from '../components/Logo';
import { commonStyles, buttonStyles, colors } from '../styles/commonStyles';
import { useLanguage } from '../contexts/LanguageContext';

interface SaleItem {
  id: string;
  product: string;
  quantity: string;
  price: number;
  time: string;
  customer?: string;
}

export default function SalesScreen() {
  const { t, isRTL } = useLanguage();
  const [salesData, setSalesData] = useState<SaleItem[]>([]);

  useEffect(() => {
    // Simulate loading sales data
    const mockSalesData: SaleItem[] = [
      {
        id: '1',
        product: t('premiumRibeyeSteak'),
        quantity: '2kg',
        price: 360,
        time: '14:30',
        customer: 'Ahmed M.'
      },
      {
        id: '2',
        product: t('lambChops'),
        quantity: '1.5kg',
        price: 330,
        time: '13:45',
        customer: 'Sarah K.'
      },
      {
        id: '3',
        product: t('groundBeefPremium'),
        quantity: '3kg',
        price: 255,
        time: '12:20',
        customer: 'David L.'
      },
      {
        id: '4',
        product: t('chickenBreast'),
        quantity: '2kg',
        price: 140,
        time: '11:15',
        customer: 'Maria G.'
      },
      {
        id: '5',
        product: t('beefTenderloin'),
        quantity: '1kg',
        price: 280,
        time: '10:30',
        customer: 'Hassan A.'
      }
    ];
    setSalesData(mockSalesData);
  }, [t]);

  const goBack = () => {
    console.log('Going back to main screen');
    router.back();
  };

  const totalSales = salesData.reduce((sum, item) => sum + item.price, 0);

  return (
    <SafeAreaView style={commonStyles.wrapper}>
      <ScrollView contentContainerStyle={commonStyles.scrollContent}>
        <View style={[commonStyles.content, { direction: isRTL ? 'rtl' : 'ltr' }]}>
          {/* Header with Logo */}
          <View style={[commonStyles.card, { alignItems: 'center', marginBottom: 20 }]}>
            <Logo size="small" showText={false} />
            <Text style={[commonStyles.title, { marginTop: 10 }]}>
              {t('salesData')}
            </Text>
            <Text style={[commonStyles.text, { color: colors.textSecondary }]}>
              {t('todaysTransactions')}
            </Text>
          </View>

          {/* Sales Summary */}
          <View style={commonStyles.card}>
            <Text style={[commonStyles.subtitle, { marginBottom: 15 }]}>
              {t('salesSummary')}
            </Text>
            <View style={{ 
              flexDirection: isRTL ? 'row-reverse' : 'row', 
              justifyContent: 'space-between',
              marginBottom: 10 
            }}>
              <Text style={commonStyles.text}>{t('totalSales')}:</Text>
              <Text style={[commonStyles.text, { color: colors.success, fontWeight: 'bold' }]}>
                {t('currency')}{totalSales}
              </Text>
            </View>
            <View style={{ 
              flexDirection: isRTL ? 'row-reverse' : 'row', 
              justifyContent: 'space-between',
              marginBottom: 10 
            }}>
              <Text style={commonStyles.text}>{t('totalTransactions')}:</Text>
              <Text style={[commonStyles.text, { color: colors.primary, fontWeight: 'bold' }]}>
                {salesData.length}
              </Text>
            </View>
            <View style={{ 
              flexDirection: isRTL ? 'row-reverse' : 'row', 
              justifyContent: 'space-between' 
            }}>
              <Text style={commonStyles.text}>{t('averageOrder')}:</Text>
              <Text style={[commonStyles.text, { color: colors.accent, fontWeight: 'bold' }]}>
                {t('currency')}{Math.round(totalSales / salesData.length)}
              </Text>
            </View>
          </View>

          {/* Sales List */}
          <View style={commonStyles.card}>
            <Text style={[commonStyles.subtitle, { marginBottom: 15 }]}>
              {t('recentTransactions')}
            </Text>
            {salesData.map((sale) => (
              <View key={sale.id} style={commonStyles.salesCard}>
                <View style={{ 
                  flexDirection: isRTL ? 'row-reverse' : 'row', 
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 8 
                }}>
                  <Text style={[commonStyles.text, { fontWeight: 'bold', flex: 1 }]}>
                    {sale.product}
                  </Text>
                  <Text style={[commonStyles.text, { color: colors.success, fontWeight: 'bold' }]}>
                    {t('currency')}{sale.price}
                  </Text>
                </View>
                <View style={{ 
                  flexDirection: isRTL ? 'row-reverse' : 'row', 
                  justifyContent: 'space-between',
                  alignItems: 'center' 
                }}>
                  <Text style={[commonStyles.text, { fontSize: 14, color: colors.textSecondary }]}>
                    {sale.quantity} • {sale.customer}
                  </Text>
                  <Text style={[commonStyles.text, { fontSize: 14, color: colors.textSecondary }]}>
                    {sale.time}
                  </Text>
                </View>
              </View>
            ))}
          </View>

          {/* Back Button */}
          <View style={commonStyles.buttonContainer}>
            <Button
              text={t('backToMain')}
              onPress={goBack}
              style={buttonStyles.backButton}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}