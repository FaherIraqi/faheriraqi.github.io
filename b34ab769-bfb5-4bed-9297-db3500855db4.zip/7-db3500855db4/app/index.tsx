import { Text, View, ScrollView, SafeAreaView, TouchableOpacity } from 'react-native';
import { router } from 'expo-router';
import { useState, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import Button from '../components/Button';
import Logo from '../components/Logo';
import LanguageSelector from '../components/LanguageSelector';
import { commonStyles, buttonStyles, colors } from '../styles/commonStyles';
import { useLanguage } from '../contexts/LanguageContext';

export default function MainScreen() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const { t, isRTL } = useLanguage();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const navigateToSales = () => {
    console.log('Navigating to sales screen');
    router.push('/sales');
  };

  const navigateToQR = () => {
    console.log('Navigating to QR code screen');
    router.push('/qr-code');
  };

  return (
    <SafeAreaView style={commonStyles.wrapper}>
      <ScrollView contentContainerStyle={commonStyles.scrollContent}>
        <View style={[commonStyles.content, { direction: isRTL ? 'rtl' : 'ltr' }]}>
          {/* Logo Section */}
          <View style={[commonStyles.card, { alignItems: 'center', marginBottom: 30 }]}>
            <Logo size="large" showText={true} />
            <Text style={[commonStyles.text, { color: colors.textSecondary, fontSize: 14, marginTop: 10 }]}>
              {t('appSubtitle')}
            </Text>
            <Text style={[commonStyles.text, { fontSize: 14, marginTop: 10 }]}>
              {currentTime.toLocaleDateString()} • {currentTime.toLocaleTimeString()}
            </Text>
          </View>

          {/* Language Selector */}
          <View style={commonStyles.card}>
            <LanguageSelector />
          </View>

          {/* Quick Stats */}
          <View style={commonStyles.card}>
            <Text style={[commonStyles.subtitle, { marginBottom: 15 }]}>
              {t('todaysOverview')}
            </Text>
            <View style={{ flexDirection: isRTL ? 'row-reverse' : 'row', justifyContent: 'space-between' }}>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={[commonStyles.text, { color: colors.success, fontSize: 20, fontWeight: 'bold' }]}>
                  {t('currency')}2,450
                </Text>
                <Text style={[commonStyles.text, { fontSize: 12 }]}>{t('salesLabel')}</Text>
              </View>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={[commonStyles.text, { color: colors.primary, fontSize: 20, fontWeight: 'bold' }]}>
                  23
                </Text>
                <Text style={[commonStyles.text, { fontSize: 12 }]}>{t('ordersLabel')}</Text>
              </View>
              <View style={{ alignItems: 'center', flex: 1 }}>
                <Text style={[commonStyles.text, { color: colors.accent, fontSize: 20, fontWeight: 'bold' }]}>
                  4.8★
                </Text>
                <Text style={[commonStyles.text, { fontSize: 12 }]}>{t('ratingLabel')}</Text>
              </View>
            </View>
          </View>

          {/* Navigation Buttons */}
          <View style={commonStyles.buttonContainer}>
            <Button
              text={t('viewSalesData')}
              onPress={navigateToSales}
              style={[buttonStyles.primary, { marginBottom: 15 }]}
            />
            <Button
              text={t('generateQRCode')}
              onPress={navigateToQR}
              style={buttonStyles.secondary}
            />
          </View>

          {/* Recent Activity */}
          <View style={[commonStyles.card, { marginTop: 20 }]}>
            <Text style={[commonStyles.subtitle, { marginBottom: 15 }]}>
              {t('recentActivity')}
            </Text>
            <View style={{ gap: 10 }}>
              <View style={{ 
                flexDirection: isRTL ? 'row-reverse' : 'row', 
                justifyContent: 'space-between', 
                alignItems: 'center' 
              }}>
                <Text style={[commonStyles.text, { textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('premiumRibeyeSteak')}
                </Text>
                <Text style={[commonStyles.text, { color: colors.success }]}>
                  {t('currency')}180
                </Text>
              </View>
              <View style={{ 
                flexDirection: isRTL ? 'row-reverse' : 'row', 
                justifyContent: 'space-between', 
                alignItems: 'center' 
              }}>
                <Text style={[commonStyles.text, { textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('lambChops')} (1{t('kg')})
                </Text>
                <Text style={[commonStyles.text, { color: colors.success }]}>
                  {t('currency')}220
                </Text>
              </View>
              <View style={{ 
                flexDirection: isRTL ? 'row-reverse' : 'row', 
                justifyContent: 'space-between', 
                alignItems: 'center' 
              }}>
                <Text style={[commonStyles.text, { textAlign: isRTL ? 'right' : 'left' }]}>
                  {t('groundBeefPremium')}
                </Text>
                <Text style={[commonStyles.text, { color: colors.success }]}>
                  {t('currency')}85
                </Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}