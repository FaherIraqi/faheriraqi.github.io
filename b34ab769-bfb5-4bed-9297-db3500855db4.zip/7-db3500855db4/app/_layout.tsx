import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Stack, useGlobalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Platform, SafeAreaView } from 'react-native';
import { setupErrorLogging } from '../utils/errorLogger';
import { commonStyles } from '../styles/commonStyles';
import { LanguageProvider } from '../contexts/LanguageContext';

const STORAGE_KEY = 'natively-storage';

export default function RootLayout() {
  const insets = useSafeAreaInsets();
  const [isReady, setIsReady] = useState(false);
  const globalSearchParams = useGlobalSearchParams();

  useEffect(() => {
    const initializeApp = async () => {
      try {
        console.log('Initializing app...');
        await setupErrorLogging();
        setIsReady(true);
        console.log('App initialized successfully');
      } catch (error) {
        console.error('Failed to initialize app:', error);
        setIsReady(true); // Still set ready to avoid infinite loading
      }
    };

    initializeApp();
  }, []);

  if (!isReady) {
    return null;
  }

  return (
    <LanguageProvider>
      <SafeAreaProvider>
        <SafeAreaView style={commonStyles.wrapper}>
          <StatusBar style="light" backgroundColor="#1A1A1A" />
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: '#1A1A1A' },
              animation: 'slide_from_right',
            }}
          >
            <Stack.Screen name="index" />
            <Stack.Screen name="sales" />
            <Stack.Screen name="qr-code" />
          </Stack>
        </SafeAreaView>
      </SafeAreaProvider>
    </LanguageProvider>
  );
}