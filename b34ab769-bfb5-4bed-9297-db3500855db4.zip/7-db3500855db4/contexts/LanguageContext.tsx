import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'ar' | 'he' | 'es';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const translations = {
  en: {
    // App Title
    appTitle: 'TIRA MEAT BOUTIQUE',
    appSubtitle: 'Premium Quality Meats',
    tiraMeatBoutique: 'Tira Meat Boutique',
    
    // Navigation
    home: 'Home',
    sales: 'Sales',
    qrCode: 'QR Code',
    language: 'Language',
    backToMain: 'Back to Main',
    
    // Home Screen
    todaysOverview: "Today's Overview",
    salesLabel: 'Sales',
    ordersLabel: 'Orders',
    ratingLabel: 'Rating',
    viewSalesData: '📊 View Sales Data',
    generateQRCode: '📱 Generate QR Code',
    recentActivity: 'Recent Activity',
    
    // Sales Screen
    salesData: 'Sales Data',
    todaysSummary: "Today's Summary",
    totalSales: 'Total Sales',
    transactions: 'Transactions',
    avgSale: 'Avg. Sale',
    recentTransactions: 'Recent Transactions',
    customer: 'Customer',
    paid: 'PAID',
    
    // QR Code Screen
    qrCodeGenerator: 'QR Code Generator',
    qrCodeTitle: 'QR Code Generator',
    businessQR: 'Business QR Code',
    storeQRCode: 'Store QR Code',
    scanToVisit: 'Scan to visit our store',
    scanWithCamera: 'Scan with your camera to visit our store',
    shareQR: 'Share QR Code',
    shareQRCode: 'Share QR Code',
    qrCodeInfo: 'Store Information',
    storeLocation: 'Visit our premium meat boutique',
    openingHours: 'Open daily 8:00 AM - 8:00 PM',
    contactNumber: 'Call us: +972-XX-XXX-XXXX',
    premiumQuality: 'Premium quality guaranteed',
    visitOurStore: 'Visit our store',
    error: 'Error',
    shareError: 'Could not share QR code',
    
    // Products
    premiumRibeyeSteak: 'Premium Ribeye Steak',
    lambShoulder: 'Lamb Shoulder',
    groundBeefPremium: 'Ground Beef Premium',
    chickenBreast: 'Chicken Breast',
    beefTenderloin: 'Beef Tenderloin',
    lambChops: 'Lamb Chops',
    turkeyBreast: 'Turkey Breast',
    vealCutlets: 'Veal Cutlets',
    
    // Units
    pieces: 'pieces',
    kg: 'kg',
    
    // Currency
    currency: '₪',
  },
  ar: {
    // App Title
    appTitle: 'تيرا بوتيك اللحوم',
    appSubtitle: 'لحوم عالية الجودة',
    tiraMeatBoutique: 'تيرا بوتيك اللحوم',
    
    // Navigation
    home: 'الرئيسية',
    sales: 'المبيعات',
    qrCode: 'رمز الاستجابة السريعة',
    language: 'اللغة',
    backToMain: 'العودة للرئيسية',
    
    // Home Screen
    todaysOverview: 'نظرة عامة على اليوم',
    salesLabel: 'المبيعات',
    ordersLabel: 'الطلبات',
    ratingLabel: 'التقييم',
    viewSalesData: '📊 عرض بيانات المبيعات',
    generateQRCode: '📱 إنشاء رمز الاستجابة السريعة',
    recentActivity: 'النشاط الأخير',
    
    // Sales Screen
    salesData: 'بيانات المبيعات',
    todaysSummary: 'ملخص اليوم',
    totalSales: 'إجمالي المبيعات',
    transactions: 'المعاملات',
    avgSale: 'متوسط البيع',
    recentTransactions: 'المعاملات الأخيرة',
    customer: 'العميل',
    paid: 'مدفوع',
    
    // QR Code Screen
    qrCodeGenerator: 'مولد رمز الاستجابة السريعة',
    qrCodeTitle: 'مولد رمز الاستجابة السريعة',
    businessQR: 'رمز الاستجابة السريعة للأعمال',
    storeQRCode: 'رمز المتجر',
    scanToVisit: 'امسح لزيارة متجرنا',
    scanWithCamera: 'امسح بالكاميرا لزيارة متجرنا',
    shareQR: 'مشاركة رمز الاستجابة السريعة',
    shareQRCode: 'مشاركة رمز الاستجابة السريعة',
    qrCodeInfo: 'معلومات المتجر',
    storeLocation: 'زر بوتيك اللحوم المميز',
    openingHours: 'مفتوح يومياً 8:00 ص - 8:00 م',
    contactNumber: 'اتصل بنا: +972-XX-XXX-XXXX',
    premiumQuality: 'جودة مميزة مضمونة',
    visitOurStore: 'زر متجرنا',
    error: 'خطأ',
    shareError: 'لا يمكن مشاركة رمز الاستجابة السريعة',
    
    // Products
    premiumRibeyeSteak: 'ستيك ريب آي ممتاز',
    lambShoulder: 'كتف خروف',
    groundBeefPremium: 'لحم بقري مفروم ممتاز',
    chickenBreast: 'صدر دجاج',
    beefTenderloin: 'فيليه لحم بقري',
    lambChops: 'قطع لحم خروف',
    turkeyBreast: 'صدر ديك رومي',
    vealCutlets: 'قطع لحم عجل',
    
    // Units
    pieces: 'قطع',
    kg: 'كيلو',
    
    // Currency
    currency: '₪',
  },
  he: {
    // App Title
    appTitle: 'טירה בוטיק בשרים',
    appSubtitle: 'בשרים באיכות פרימיום',
    tiraMeatBoutique: 'טירה בוטיק בשרים',
    
    // Navigation
    home: 'בית',
    sales: 'מכירות',
    qrCode: 'קוד QR',
    language: 'שפה',
    backToMain: 'חזרה לעמוד הראשי',
    
    // Home Screen
    todaysOverview: 'סקירת היום',
    salesLabel: 'מכירות',
    ordersLabel: 'הזמנות',
    ratingLabel: 'דירוג',
    viewSalesData: '📊 צפה בנתוני מכירות',
    generateQRCode: '📱 צור קוד QR',
    recentActivity: 'פעילות אחרונה',
    
    // Sales Screen
    salesData: 'נתוני מכירות',
    todaysSummary: 'סיכום היום',
    totalSales: 'סך המכירות',
    transactions: 'עסקאות',
    avgSale: 'ממוצע מכירה',
    recentTransactions: 'עסקאות אחרונות',
    customer: 'לקוח',
    paid: 'שולם',
    
    // QR Code Screen
    qrCodeGenerator: 'מחולל קוד QR',
    qrCodeTitle: 'מחולל קוד QR',
    businessQR: 'קוד QR עסקי',
    storeQRCode: 'קוד QR של החנות',
    scanToVisit: 'סרוק כדי לבקר בחנות שלנו',
    scanWithCamera: 'סרוק עם המצלמה כדי לבקר בחנות שלנו',
    shareQR: 'שתף קוד QR',
    shareQRCode: 'שתף קוד QR',
    qrCodeInfo: 'מידע על החנות',
    storeLocation: 'בקר בבוטיק הבשרים המובחר שלנו',
    openingHours: 'פתוח מדי יום 8:00-20:00',
    contactNumber: 'התקשר אלינו: +972-XX-XXX-XXXX',
    premiumQuality: 'איכות מובחרת מובטחת',
    visitOurStore: 'בקר בחנות שלנו',
    error: 'שגיאה',
    shareError: 'לא ניתן לשתף את קוד ה-QR',
    
    // Products
    premiumRibeyeSteak: 'סטייק ריב איי פרימיום',
    lambShoulder: 'כתף כבש',
    groundBeefPremium: 'בשר בקר טחון פרימיום',
    chickenBreast: 'חזה עוף',
    beefTenderloin: 'פילה בקר',
    lambChops: 'צלעות כבש',
    turkeyBreast: 'חזה הודו',
    vealCutlets: 'קציצות עגל',
    
    // Units
    pieces: 'חתיכות',
    kg: 'ק״ג',
    
    // Currency
    currency: '₪',
  },
  es: {
    // App Title
    appTitle: 'TIRA BOUTIQUE DE CARNES',
    appSubtitle: 'Carnes de Calidad Premium',
    tiraMeatBoutique: 'Tira Boutique de Carnes',
    
    // Navigation
    home: 'Inicio',
    sales: 'Ventas',
    qrCode: 'Código QR',
    language: 'Idioma',
    backToMain: 'Volver al Inicio',
    
    // Home Screen
    todaysOverview: 'Resumen de Hoy',
    salesLabel: 'Ventas',
    ordersLabel: 'Pedidos',
    ratingLabel: 'Calificación',
    viewSalesData: '📊 Ver Datos de Ventas',
    generateQRCode: '📱 Generar Código QR',
    recentActivity: 'Actividad Reciente',
    
    // Sales Screen
    salesData: 'Datos de Ventas',
    todaysSummary: 'Resumen de Hoy',
    totalSales: 'Ventas Totales',
    transactions: 'Transacciones',
    avgSale: 'Venta Promedio',
    recentTransactions: 'Transacciones Recientes',
    customer: 'Cliente',
    paid: 'PAGADO',
    
    // QR Code Screen
    qrCodeGenerator: 'Generador de Código QR',
    qrCodeTitle: 'Generador de Código QR',
    businessQR: 'Código QR del Negocio',
    storeQRCode: 'Código QR de la Tienda',
    scanToVisit: 'Escanea para visitar nuestra tienda',
    scanWithCamera: 'Escanea con tu cámara para visitar nuestra tienda',
    shareQR: 'Compartir Código QR',
    shareQRCode: 'Compartir Código QR',
    qrCodeInfo: 'Información de la Tienda',
    storeLocation: 'Visita nuestro boutique de carnes premium',
    openingHours: 'Abierto diariamente 8:00 AM - 8:00 PM',
    contactNumber: 'Llámanos: +972-XX-XXX-XXXX',
    premiumQuality: 'Calidad premium garantizada',
    visitOurStore: 'Visita nuestra tienda',
    error: 'Error',
    shareError: 'No se pudo compartir el código QR',
    
    // Products
    premiumRibeyeSteak: 'Bistec Ribeye Premium',
    lambShoulder: 'Paleta de Cordero',
    groundBeefPremium: 'Carne Molida Premium',
    chickenBreast: 'Pechuga de Pollo',
    beefTenderloin: 'Solomillo de Res',
    lambChops: 'Chuletas de Cordero',
    turkeyBreast: 'Pechuga de Pavo',
    vealCutlets: 'Chuletas de Ternera',
    
    // Units
    pieces: 'piezas',
    kg: 'kg',
    
    // Currency
    currency: '₪',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations[typeof language]] || key;
  };

  const isRTL = language === 'ar' || language === 'he';

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    isRTL,
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};