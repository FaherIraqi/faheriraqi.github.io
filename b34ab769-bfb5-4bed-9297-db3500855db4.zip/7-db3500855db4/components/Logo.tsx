import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../styles/commonStyles';

interface LogoProps {
  size?: 'small' | 'medium' | 'large';
  showText?: boolean;
}

export default function Logo({ size = 'medium', showText = true }: LogoProps) {
  const logoSize = size === 'small' ? 60 : size === 'medium' ? 100 : 140;
  const iconSize = size === 'small' ? 24 : size === 'medium' ? 40 : 56;
  const textSize = size === 'small' ? 16 : size === 'medium' ? 24 : 32;
  const subtitleSize = size === 'small' ? 10 : size === 'medium' ? 14 : 18;

  return (
    <View style={[styles.container, { alignItems: 'center' }]}>
      {/* Logo Circle with Meat/Butcher Icon */}
      <View style={[
        styles.logoCircle, 
        { 
          width: logoSize, 
          height: logoSize, 
          borderRadius: logoSize / 2 
        }
      ]}>
        {/* Gradient effect using multiple circles */}
        <View style={[
          styles.innerCircle,
          {
            width: logoSize - 8,
            height: logoSize - 8,
            borderRadius: (logoSize - 8) / 2,
          }
        ]}>
          {/* Using storefront icon instead of fork/knife */}
          <Ionicons name="storefront" size={iconSize} color={colors.background} />
        </View>
      </View>

      {/* Business Name */}
      {showText && (
        <View style={styles.textContainer}>
          <Text style={[styles.businessName, { fontSize: textSize }]}>
            TIRA MEAT
          </Text>
          <Text style={[styles.businessSubtitle, { fontSize: subtitleSize }]}>
            BOUTIQUE
          </Text>
          <View style={styles.decorativeLine} />
          <Text style={[styles.tagline, { fontSize: subtitleSize - 2 }]}>
            Premium Quality Meats
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoCircle: {
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: colors.accent,
    boxShadow: '0px 6px 12px rgba(212, 175, 55, 0.4)',
    elevation: 8,
  },
  innerCircle: {
    backgroundColor: colors.secondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textContainer: {
    alignItems: 'center',
    marginTop: 15,
  },
  businessName: {
    fontWeight: '900',
    color: colors.primary,
    letterSpacing: 2,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  businessSubtitle: {
    fontWeight: '600',
    color: colors.text,
    letterSpacing: 4,
    textAlign: 'center',
    marginTop: 2,
  },
  decorativeLine: {
    width: 60,
    height: 2,
    backgroundColor: colors.primary,
    marginVertical: 8,
  },
  tagline: {
    fontWeight: '400',
    color: colors.textSecondary,
    textAlign: 'center',
    fontStyle: 'italic',
  },
});